package com.example.imagefilters

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.mukesh.image_processing.ImageProcessor

class MainActivity : AppCompatActivity() {
    lateinit var bitmap:Bitmap
    lateinit var processedBitmap:Bitmap
    lateinit var ivMain:ImageView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ivMain = findViewById(R.id.ivMain)
        bitmap = BitmapFactory.decodeResource(resources,R.drawable.firstfoto)
        val processor = ImageProcessor()
        processedBitmap = processor.tintImage(bitmap,120)

        ivMain.setImageBitmap(processedBitmap)
    }
}